import 'package:flutter/material.dart';
import 'package:hayat_app/pages/articles.dart';
import 'package:hayat_app/pages/statistics.dart';
import 'package:hayat_app/pages/tasks.dart';

final allPages = <_Page>[
  _Page(
    label: "Articles",
    widget: ArticlesPage(),
    color: Colors.redAccent,
    icon: Icons.label_outline,
  ),
  _Page(
    label: "Tasks",
    widget: TasksPage(),
    color: Colors.greenAccent,
    icon: Icons.dashboard,
  ),
  _Page(
    label: "Stastics",
    widget: StatisticsPage(),
    color: Colors.amberAccent,
    icon: Icons.language,
  ),
];

class _Page {
  _Page({this.label, this.widget, this.color, this.icon});

  final String label;
  final Widget widget;
  final Color color;
  final IconData icon;
}

void main() => runApp(MainApp());

class MainApp extends StatelessWidget {
  static const _TITLE = "Hayat App";

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: _TITLE,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: HomePage(title: _TITLE),
    );
  }
}

class HomePage extends StatefulWidget {
  HomePage({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    int _index = 0;

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Container(
        child: allPages[_index].widget,
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: allPages.map(
              (page) => BottomNavigationBarItem(
                    backgroundColor: page.color,
                    title: Text(page.label),
                    icon: Icon(page.icon),
                  ),
            )
            .toList(),
        currentIndex: _index,
        selectedItemColor: Colors.brown,
        onTap: (i) {
          setState(() {
            _index = i;
          });
        },
      ),
    );
  }
}
